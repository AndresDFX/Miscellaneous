from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import WorkerViewSet, SupportViewSet, SupportAssignmentViewSet

router = DefaultRouter()
router.register(r'workers', WorkerViewSet)
router.register(r'supports', SupportViewSet)
router.register(r'assignments', SupportAssignmentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]