import pytest
from support_management.models import Worker, Support

@pytest.mark.django_db
def test_assign_support_based_on_lowest_complexity_load():
    worker1 = Worker.objects.create(name="Carolina")
    worker2 = Worker.objects.create(name="Felipe")

    support1 = Support.objects.create(description="Support 1", complexity=10)
    support2 = Support.objects.create(description="Support 2", complexity=20)

    support1.assign_support()
    assert support1.assigned_to == worker1
    worker1.refresh_from_db()
    assert worker1.assigned_complexity == 10

    support2.assign_support()
    assert support2.assigned_to == worker2
    worker2.refresh_from_db()
    assert worker2.assigned_complexity == 20

@pytest.mark.django_db
def test_complete_support_and_update_worker_load():
    worker = Worker.objects.create(name="Andres")
    support = Support.objects.create(description="Support", complexity=15, assigned_to=worker)

    # Completar el soporte una sola vez
    support.complete_support()
    worker.refresh_from_db()
    assert worker.assigned_complexity == 0

@pytest.mark.django_db
def test_no_assignment_for_completed_or_already_assigned_support():
    worker = Worker.objects.create(name="Laura")
    support = Support.objects.create(description="Support", complexity=10, assigned_to=worker, is_assigned=True)

    # Intentar completar el soporte una sola vez
    support.complete_support()
    worker.refresh_from_db()
    assert worker.assigned_complexity == 0


@pytest.mark.django_db
def test_reassignment_of_support_to_least_busy_worker():
    # Crear tres trabajadores con diferentes cargas
    worker1 = Worker.objects.create(name="Maria", assigned_complexity=10)
    worker2 = Worker.objects.create(name="Jose", assigned_complexity=5)
    worker3 = Worker.objects.create(name="Luis", assigned_complexity=15)

    # Crear un nuevo soporte
    new_support = Support.objects.create(description="New Support", complexity=10)
    new_support.assign_support()

    # Verificar que el soporte se asigne al trabajador menos ocupado (Jose)
    assert new_support.assigned_to == worker2
    worker2.refresh_from_db()
    assert worker2.assigned_complexity == 15  # 5 (existente) + 10 (nuevo)