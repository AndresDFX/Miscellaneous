from rest_framework.test import APITestCase
from rest_framework import status
from django.urls import reverse
from support_management.models import Worker, Support, SupportAssignment

class WorkerViewSetTestCase(APITestCase):
    def test_create_worker(self):
        url = reverse('worker-list')
        data = {'name': 'John Doe'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Worker.objects.count(), 1)
        self.assertEqual(Worker.objects.get().name, 'John Doe')

class SupportViewSetTestCase(APITestCase):
    def setUp(self):
        self.worker = Worker.objects.create(name='John Doe')

    def test_create_support(self):
        url = reverse('support-list')
        data = {'description': 'Test Support', 'complexity': 10}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Support.objects.count(), 1)
        self.assertEqual(Support.objects.get().description, 'Test Support')

    def test_assign_support(self):
        support = Support.objects.create(description='Test Support', complexity=10)
        url = reverse('support-assign', args=[support.id])
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        support.refresh_from_db()
        self.assertEqual(support.assigned_to, self.worker)

class SupportAssignmentViewSetTestCase(APITestCase):
    def setUp(self):
        self.worker = Worker.objects.create(name='John Doe')
        self.support = Support.objects.create(description='Test Support', complexity=10)

    def test_create_support_assignment(self):
        url = reverse('supportassignment-list')
        data = {'support': self.support.id, 'worker': self.worker.id}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(SupportAssignment.objects.count(), 1)
