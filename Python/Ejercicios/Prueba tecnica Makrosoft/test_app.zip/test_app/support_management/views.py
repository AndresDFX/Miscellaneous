from rest_framework import viewsets
from .models import Worker, Support, SupportAssignment
from .serializers import WorkerSerializer, SupportSerializer, SupportAssignmentSerializer
from rest_framework.decorators import action
from rest_framework.response import Response

class WorkerViewSet(viewsets.ModelViewSet):
    queryset = Worker.objects.all()
    serializer_class = WorkerSerializer

class SupportViewSet(viewsets.ModelViewSet):
    queryset = Support.objects.all()
    serializer_class = SupportSerializer

    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        support = self.get_object()
        if support.is_assigned or support.is_completed:
            return Response({'error': 'Support is already assigned or completed'}, status=400)

        assigned_worker = support.assign_support()
        if assigned_worker:
            return Response({'assigned_to': assigned_worker.name})
        else:
            return Response({'error': 'No available workers'}, status=400)

class SupportAssignmentViewSet(viewsets.ModelViewSet):
    queryset = SupportAssignment.objects.all()
    serializer_class = SupportAssignmentSerializer
