from rest_framework import serializers
from .models import Worker, Support, SupportAssignment

class WorkerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Worker
        fields = '__all__'

class SupportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Support
        fields = '__all__'

class SupportAssignmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportAssignment
        fields = '__all__'
