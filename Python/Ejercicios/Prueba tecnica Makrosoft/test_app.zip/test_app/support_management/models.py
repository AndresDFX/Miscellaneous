from django.db import models


class Worker(models.Model):
    name = models.CharField(max_length=100)
    assigned_complexity = models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Support(models.Model):
    COMPLEXITY_CHOICES = [
        (10, 'Low'),
        (20, 'Medium'),
        (30, 'High'),
    ]
    description = models.TextField()
    complexity = models.IntegerField(choices=COMPLEXITY_CHOICES)
    is_assigned = models.BooleanField(default=False)
    is_completed = models.BooleanField(default=False)
    assigned_to = models.ForeignKey(Worker, on_delete=models.SET_NULL, null=True, blank=True)

    def assign_support(self):
        if self.is_assigned or self.is_completed:
            return None

        worker = Worker.objects.order_by('assigned_complexity').first()
        if worker:
            self.assigned_to = worker
            self.is_assigned = True
            self.save()
            # Crear una entrada en SupportAssignment
            SupportAssignment.objects.create(support=self, worker=worker)
            # Actualizar la complejidad asignada del trabajador
            worker.assigned_complexity += self.complexity
            worker.save()
            return worker
        return None

    def complete_support(self):
        if not self.is_completed:
            self.is_completed = True
            if self.assigned_to:
                new_complexity = self.assigned_to.assigned_complexity - self.complexity
                self.assigned_to.assigned_complexity = max(new_complexity, 0)
                self.assigned_to.save()
            self.save()

    def __str__(self):
        return f"{self.description[:50]}..."

class SupportAssignment(models.Model):
    support = models.ForeignKey(Support, on_delete=models.CASCADE)
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE)
    date_assigned = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.support} -> {self.worker}"
