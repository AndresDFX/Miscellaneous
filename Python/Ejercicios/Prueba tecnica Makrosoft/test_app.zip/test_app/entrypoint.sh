#!/bin/bash

# Esperar a que PostgreSQL esté listo
while ! nc -z $DB_HOST $DB_PORT; do
  sleep 0.1
done

# Aplicar migraciones
python manage.py process_tasks &
python manage.py migrate

# Iniciar el servidor de desarrollo de Django
python manage.py runserver 0.0.0.0:8000
